package communication;

/**
 * Created by devkkda on 10/16/2016.
 */
public class Communication {

//    public static final String SERVER_LOCATION_Domain_Name = "http://www.yt-mp3.com";
//    public static final String SERVER_FETCH = "/fetch?v=";
    public static final String SERVER_LOCATION_Domain_Name = "https://www.youtubeinmp3.com/fetch/?format=JSON&video=";
    public static final String SERVER_FETCH = "http://www.youtube.com/watch?v=";


}
