package me.amald.youtubedownloader.Util;

/**
 * Created by amald on 15/1/17.
 */

public class constants {


    public static String moburl = ".be";
    public static String weburl = ".com";

}
